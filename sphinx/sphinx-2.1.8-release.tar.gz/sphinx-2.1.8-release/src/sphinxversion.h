#define SPH_SVN_TAG "rel21"
#define SPH_SVN_REV 4675
#define SPH_SVN_REVSTR "4675"
#define SPH_SVN_TAGREV "rel21-r4675"
