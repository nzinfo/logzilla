#define SPH_SVN_TAG ""
#define SPH_SVN_REV 4843
#define SPH_SVN_REVSTR "4843"
#define SPH_SVN_TAGREV "r4843"
